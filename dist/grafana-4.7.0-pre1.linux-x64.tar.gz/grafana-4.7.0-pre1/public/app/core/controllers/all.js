define([
  './inspect_ctrl',
  './json_editor_ctrl',
  './login_ctrl',
  './invited_ctrl',
  './signup_ctrl',
  './reset_password_ctrl',
  './error_ctrl',
], function () {});
