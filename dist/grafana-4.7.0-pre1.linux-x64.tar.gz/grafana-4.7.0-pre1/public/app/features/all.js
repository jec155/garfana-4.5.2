define([
  './panellinks/module',
  './dashlinks/module',
  './annotations/all',
  './templating/all',
  './plugins/all',
  './dashboard/all',
  './playlist/all',
  './snapshot/all',
  './panel/all',
  './styleguide/styleguide',
], function () {});
