#### Alias patterns
- {{term fieldname}} = replaced with value of term group by
- {{metric}} = replaced with metric name (ex. Average, Min, Max)
- {{field}} = replaced with the metric field name

#### Documentation links

[Grafana's Elasticsearch Documentation](http://docs.grafana.org/features/datasources/elasticsearch)

[Official Elasticsearch Documentation](https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html)
