# OpenTSDB Datasource -  Native Plugin

Grafana ships with **built in** support for OpenTSDB, a scalable, distributed time series database.

Read more about it here:

[http://docs.grafana.org/datasources/opentsdb/](http://docs.grafana.org/datasources/opentsdb/)